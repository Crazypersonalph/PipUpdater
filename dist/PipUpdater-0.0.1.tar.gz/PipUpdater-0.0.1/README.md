# PipUpdater
![GitHub](https://img.shields.io/github/license/Crazypersonalph/PipUpdater?style=for-the-badge) ![GitHub issues](https://img.shields.io/github/issues/Crazypersonalph/PipUpdater?style=for-the-badge)

<p xmlns:dct="http://purl.org/dc/terms/" xmlns:vcard="http://www.w3.org/2001/vcard-rdf/3.0#">
  <a rel="license"
     href="http://creativecommons.org/publicdomain/zero/1.0/">
    <img src="https://licensebuttons.net/p/zero/1.0/88x31.png" style="border-style: none;" alt="CC0" />
  </a>
  <br />
  To the extent possible under law,
  <a rel="dct:publisher"
     href="https://github.com/Crazypersonalph/PipUpdater">
    <span property="dct:title">Alphons Joseph</span></a>
  has waived all copyright and related or neighboring rights to
  <span property="dct:title">PipUpdater</span>.
This work is published from:
<span property="vcard:Country" datatype="dct:ISO3166"
      content="AU" about="https://github.com/Crazypersonalph/PipUpdater">
  Australia</span>.
</p>


### Are you ever tired of having to upgrade all your packages when a new update comes, or some other thing breaks?
Sometimes, you might have HUNDREDS of packages, and it is impossible to keep track of them.
### This is a python package being developed for PyPi, that will be able to upgrade all of your packages.

This is package is open-source, and in the public domain. \
That means anybody can use, repackage, and you don't have to worry about anything when it comes to licensing.

Please spread the word! \
Thanks!
